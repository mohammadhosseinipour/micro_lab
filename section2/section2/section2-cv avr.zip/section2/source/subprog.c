#include <header.h>

int sevseg[]={0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F};

void sub1(int count,int portid,int timems)
{
    int i;
    switch(portid){
    case 1:
    PORTA=0x00;
    for(i=0;i<count*2;i++)
    {
        PORTA ^=0xff;
        delay_ms(timems);
    }
    PORTA=0x00;
    break;

    case 2:
    PORTB=0x00;
    for(i=0;i<count*2;i++)
    {
        PORTB ^=0xff;
        delay_ms(timems);
    }
    PORTB=0x00;
    break;

    case 3:
    PORTC=0x00;
    for(i=0;i<count*2;i++)
    {
        PORTC ^=0xff;
        delay_ms(timems);
    }
    PORTC=0x00;
    break;

    case 4:
    PORTD=0x00;
    for(i=0;i<count*2;i++)
    {
        PORTD ^=0xff;
        delay_ms(timems);
    }
    PORTD=0x00;
    break;

    default:
    }

}


void sub2(int loc,int timems) //location : 0-7
{
    int i;
    int a=0b00000001;
    a=a<<loc;
    for(i=0;i<(timems/375);i++)
    {
    PORTB=a;
    a=a<<1;
    delay_ms(375);
    if(a==0b100000000)
    {
        a=0b00000001;
    }

    }
    PORTB=0x00;
}



void sub3(char portout,char portin)
{
    int i=0;
    switch(portin){
    case 1:
        switch(portout){
        case 2:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTB=PINA;
            }
        case 3:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTC=PINA;
            }
        case 4:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTD=PINA;
            }
        default:
            break;}
    case 2:
        switch(portout){
        case 1:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTA=PINB;
            }
        case 3:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTC=PINB;
            }
        case 4:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTD=PINB;
            }
         default:
            break;}

    case 3:
        switch(portout){
        case 2:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTB=PINC;
            }
        case 1:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTA=PINC;
            }
        case 4:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTD=PINC;
            }
        default:
            break; }

    case 4:
        switch(portout){
        case 2:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTB=PIND;
            }
        case 3:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTC=PIND;
            }
        case 1:
            for(i=0;i<300;i++) //this loop runs for 3 seconds
            {
            delay_ms(10);
            PORTA=PIND;
            }
        default:
            break; }
    default:
            break;}

}

void sub4(int descending,int sevsegnum) // seven segment number:0-3
{
    int i;
    PORTD=~(0b00000001<<sevsegnum);
    if(descending==1)
    {
        for(i=9;i>=0;i--)
        {
            PORTC=sevseg[i];
            delay_ms(500);
        }
    }
    else
    {
        for(i=0;i<=9;i++)
        {
            PORTC=sevseg[i];
            delay_ms(500);
        }
    }
}

void sub5(float dec)
{
    int  num, decimal_val = 0, base = 1, rem;
    int firstseg,secondseg,thirdseg,fourthseg;
    int ournum=decimal_val;
    num=PINA;
    //this while calculates deciimal number
    while (num > 0)
    {
        rem = num % 10;
        decimal_val = decimal_val + rem * base;
        num = num / 10 ;
        base = base * 2;
    }
    ournum=decimal_val *10;
    while(ournum>0)
    {
        firstseg=ournum%10;
        secondseg=(ournum/10)%10;
        thirdseg=(ournum/100)%10;
        fourthseg=(ournum/1000)%10;

        PORTD=0b00000111;
        PORTC=sevseg[firstseg];
        delay_ms(100);

        PORTD=0b00001011;
        PORTC=sevseg[secondseg]|0b10000000;  /*0b10000000 is for dot*/
        delay_ms(100);

        PORTD=0b00001101;
        PORTC=sevseg[thirdseg];
        delay_ms(100);

        PORTD=0b00001110;
        PORTC=sevseg[fourthseg];
        delay_ms(100);
        ournum= ournum-dec*10;
    }
}
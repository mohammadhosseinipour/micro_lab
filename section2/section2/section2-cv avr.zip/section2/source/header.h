#ifndef _header_INCLUDED_
#define _header_INCLUDED_

#include <mega16.h>
#include <delay.h>
#include <subprog.h>
#define porta 1
#define portb 2
#define portc 3
#define portd 4



#endif

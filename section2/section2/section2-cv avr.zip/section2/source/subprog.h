#ifndef _subprog_INCLUDED_
#define _subprog_INCLUDED_

void sub1(int count,int portid,int timems);
void sub2(int loc,int timems);
void sub3(char portout,char portin);
void sub4(int descending,int sevsegnum);
void sub5(float dec);

#endif
